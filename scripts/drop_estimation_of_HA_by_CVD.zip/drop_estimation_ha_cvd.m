% Matlab script to replicate the result related to
% the estimated drop in HA by CVD in the first 
% 15 months of the COVID-19 pandemic, from t(n) and c_a(n) 

% Paulo Esquef, July 2026

clear all
close all
clc


load adjusted_time_series.mat  % loads adjusted time series in vector y
% the the time series of
% the monthly number of hospital admissions due to cardiovascular 
% diseases (per million inhabitants) in the Brazilian 
% public-health system (SUS), 
% from January 2012 to December 2025

L=length(y);  % number of elements of y(n);
% L=168 samples for the time series at hand (from January 2012 to December 2025);

F=24; % Forecast horizon of 24 samples

Nx=144;  % Nx is the time index of the cutoff month of December 2023.  

yo=y;  % stores in vector yo the original values of y 

% Temporal Selection 
y_training=y(1:Nx);  % trims off the last F=24 samples of y(n) to form y_training(n)
y_training=y_training(:);  % makes y_training a column vector 
mu=mean(y_training);  % calculates the mean of y_training and stores it in \mu

y_training=y_training-mu; % removes the mean out of y_training
% y_training is zero-mean now
 
% PATV Decomposition (via patvmm.m) of y_training(n)

% Decomposition Model
% y_training(n) = t(n) + c(n) + s(n)
% t(n) is a d^th-order polynomial
% c(n) is by construction a piecewise constant function
% s(n) is whatever remains after removing t(n) and c(n) from y_training(n)

% PATV receives y_training(n) and outputs t(n) and c(n)
% after correcting the amplitude of c(n), i.e., c_a(n)=g*c(n) (see below)
% s(n) = y_training(n) - t(n) - c_a(n)  is the seasonal component

% PATV setup parameters chosen heuristically (see paper)

d=2; % order of the polynomial that generates t(n) 
N_ite = 100;  % maximum number of iterations (PATV)
lambda = 140;  % chosen value of lambda so that c_a(n) shows a 
% sag (related to the drop in hospital admissions) with the fewest number of levels
% (visual calibration; see paper)

% Runs the PATV decomposition of y_training(n)
[c, t, bi] = patv_MM(y_training, d, lambda, N_ite);  % outputs c(n), t(n) and 
% the polynomial coefficients bi that generate t(n)

% c is a piece-wise constant component c(n) that captures part of the drop in HA
% t is  d^th-order polynomial component t(n)
% bi are the coefficients of the polynomial that generate t(n)

% Correction of the amplitude scale of c(n); (see paper)

w=y_training-t;  % noisy version of c(n)

g=(c'*w)/(c'*c);   % calculates the gain that corrects the amplitude of c(n)

c_a=g*c; % corrects the amplitude of c(n) and forms the sequence c_a(n)

% Now, we use t(n) and c_a(n) to estimate the effective drop in HA by CVD

n_ini_covid=99;  % time index of March 2020 (beginning of the COVID-19 pandemic)

baseline_pre_COVID=mean(yo(n_ini_covid-15:n_ini_covid-1)); % baseline of mean HA in the 15 months pre COVID-19

rg_post_covid=n_ini_covid+(1:15);  % time index range of 15 months post COVID-19

drop=mean(t(rg_post_covid))+mean(c_a(rg_post_covid));  % estimated drop (negative) of HA post COVID 

level_post_covid=baseline_pre_COVID+drop;

reduction=100-100*(level_post_covid/baseline_pre_COVID);

% fprintf reduction
% Display the reduction percentage in hospital admissions
fprintf('Estimated reduction in HA by CVD: %.2f%%\n', reduction);


function [x, p, pc, cost, u, v] = patv_MM(y, d, lambda, Nit)
% [x, p, cost] = patv_MM(y, d, lambda, Nit)
% PATV: Simultaneous polynomial approximation and total variation denoising.
% Algorithm based on MM algorithm.
%
% INPUT
%   y - noisy data
%   d - order of polynomial
%   lambda - regularization parameter
%   Nit - number of iterations
%
% OUTPUT
%   x - TV component
%   p - polynomial component
%   cost - cost function history

% Ivan Selesnick, selesi@poly.edu
% Polytechnic Institute of New York University
% November 2012
% Reference: 'Simultaneous least square polynomial approximation and total variation denoising'
% ICASSP 2013

y = y(:);                   % convert to column vector
cost = zeros(1,Nit);        % cost function history
N = length(y);

G = orth(bsxfun(@power, (0:N-1)', 0:d));

e = ones(N-1,1);
STSinv = spdiags([-e 2*e -e], [-1 0 1], N-1, N-1);
STSinv(1,1) = 1;

S = @(x) [0; cumsum(x)];                % S : cumulative sum 
rev = @(x) x(end:-1:1,:);               % rev : reverse elements of vector
ST = @(x) rev(cumsum(rev(x(2:end,:)))); % ST : S'
H = @(x) x - G * (G'*x);                % H : I - G G'
B = ST(G);
C = G'*G;

b = ST(H(y));                           % b : S'*H(y);
u = ones(N-1, 1);                       % Initialization
x = S(u);
Dx = u;                                 % Dx = D*x = D*S*u = I*u = u

for k = 1:Nit        
    Lam = spdiags(abs(Dx)/lambda, 0, N-1, N-1);
    R = STSinv + Lam;                           % size(R) : (N-1) x (N-1)
    invA = @(x) Lam * (x - R \ (Lam * x));      % invA : (N-1) -> (N-1)
    Q = C - B' * invA(B);                       % Q : size(Q) = (d+1) x (d+1)
    u = invA(b + B * (Q \ (B' * invA(b))));    
    x = S(u);
    Dx = u;                             % Dx = D*x = D*S*u = I*u = u
    cost(k) = lambda * sum(abs(Dx)) + 0.5 * sum(abs(H(x - y)).^2);
end

p = G * (G' * (y - x));
v = ST(H(y - x));

% Obtain polynomial coefficients pc
G = (bsxfun(@power, (0:N-1)', 0:d));
%pc=(G' * (y - x));
pc=(G'*G)\(G'* (y - x));

end