% Script to generate Figure 5 of the paper

% Paulo Esquef, July 2026

clear all; close all; clc

load adjusted_time_series.mat  % loads adjusted time series in vector y

Ly=length(y); % length of y 

% Prediction Model Setup

F=24; % forecast horizon

y_testing=y(end-(F-1):end); % selects the F last samples of y for 
% prediction performance evaluation

y=y(1:Ly-F);  % actual time series used for training the predictor


% Fixed Predictor Setup, except for the values of lambda and p_arima
% PATV parameters:
d=2;  % second-order order of the polynomial trend
%lambda=140; % sag sensitivity parameter 
N_ite=100; % maximum number of iterations in PATV 
% SARIMA model parameters
%p_arima=10; % order of the AR term
D_arima=0; % order of the non-seasonal integration term
q_arima=0; % order of the MA term
s_arima=12; % seasonality


lambda_v=50:5:150;    % range of values of lambda in vector lambda_v
pAR_v=0:20;           % range of values of p_arima in vector pAR_v

% Initializes null matrix to store measured performance, i.e., the
% map MRE(lambda,p)
PMRE=zeros(length(lambda_v),length(pAR_v)); 


cond=0;  % choose from the set {0,1}

% cond=1: PMRE will be calculated from scratch. Takes quite a while to
% execute.

% cond=0: pre-calculated PMRE will be loaded


if cond
    k=0;
    for lambda=lambda_v
        k=k+1;
        n=0;
        for p_arima=pAR_v
            [y_hat,y_hat_2p5,y_hat_97p5] = predcardio(y,F,d,lambda,N_ite,...
                p_arima,D_arima,q_arima,s_arima);
            % Measure performance in the MRE sense
            error=(y_testing-y_hat); % error between actual and forecast values
            Ne=length(error); % length of the error sequence
            relative_error=error./y_testing;  % relative error between actual 
            % and forecast values
            MRE=100*mean(abs(relative_error)); % mean relative error in %
            %%%%%%%%%%%%%%%%%%   
    
            n=n+1;
            PMRE(k,n)=MRE;
            
        end
    end
else
    load matrix_MRE_map % loads pre-calculated matrix PMRE (map of MRE(lambda,p)) 
end


figure
imagesc(PMRE)
set(gca,'FontSize',15)
xlabel('$p$','Interpreter','latex')
ylabel('$\lambda$','Interpreter','latex')
xticks(1:21)
xticklabels({0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20})
yticks(1:21)
yticklabels({50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150})
colorbar

% Finds optimal pair (lambda,p)

min_col=min(PMRE);
ind_col=find(min_col==min(min_col));

min_row=min(PMRE');
ind_row=find(min_row==min(min_row));

% columns are pAR_v values
% rows are lambda_v values
% optimal pair
lam_opt_MRE=lambda_v(ind_row);
p_opt_MRE=pAR_v(ind_col);
%[lambda_v(ind_row) pAR_v(ind_col)]

fprintf('Optimal lambda: %.1f\n', lambda_v(ind_row));
fprintf('Optimal p: %.1f\n', pAR_v(ind_col));

