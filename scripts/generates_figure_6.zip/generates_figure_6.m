% Script to generate Figure 6 of the paper

% Paulo Esquef, Nov 2026

clear all; close all; clc

load adjusted_time_series.mat  % loads adjusted time series in vector y

Ly=length(y); % length of y 

% Prediction Model Setup

F=24; % forecast horizon

y=y(1:Ly);  % actual time series used for training the predictor


% PATV parameters:
d=2;  % second-order order of the polynomial trend
lambda=140; % sag sensitivity parameter 
N_ite=100; % maximum number of iterations in PATV 
% SARIMA model parameters
p_arima=10; % order of the AR term
D_arima=0; % order of the non-seasonal integration term
q_arima=0; % order of the MA term
s_arima=12; % seasonality


% Runs the prediction model with reference implementation

[y_hat,y_hat_2p5,y_hat_97p5] = predcardio(y,F,d,lambda,N_ite,...
    p_arima,D_arima,q_arima,s_arima);


% Plots the original series and the attained 
% forecast with the 95% confidence prediction interval
figure
plot(y,'b','linewidth',3); hold on; 
set(gcf,'position',[695   273   744   506])
set(gca,'FontSize',15)
y2 = y_hat'; % mean forecast 
rgf = Ly+(1:F);
curve1 = y_hat_97p5';
curve2 = y_hat_2p5';
x2 = [rgf, fliplr(rgf)];
inBetween = [curve1, fliplr(curve2)];

fill(x2, inBetween, [0.851 0.91 0.8339]);
hold on;
plot(rgf, y2, 'r', 'LineWidth', 3);
set(gcf,'position',[695   273   744   506])
hx=xlabel('$n$ (time index)');
ylabel('HA by CVD per Million Inhab.')
hl=legend('Actual - Jan/24 to Dec/25','95\% PI','Forecast - Jan/26 to Dec/27','Location','Northwest');
set(hx,'interpreter','latex');
set(hl,'interpreter','latex','FontSize',18);
axis([145 193 250 470])



% Reference implementation of the proposed forecast method 
% The application scope is specific: 
% forecasting for the monthly number of
% hospital admissions due to cardiovascular diseases (per million inhabitants)
% in the public-health system (SUS), in Brazil 

% Paulo Esquef, November 2026


function [y_hat,y_hat_2p5,y_hat_97p5]=predcardio(y,F,d,lambda,N_ite,...
    p_arima,D_arima,q_arima,s_arima)

% INPUTS:
% y: input time series (adjusted per million inhabitants)
% F: forecast horizon in number of months
% (must be way smaller than the length of y)
% PATV parameters:
% d: order of the polynomial trend
% lambda: sag sensitivity parameter (initial guess: 
% set lambda = largest drop in the time series)
% N_ite: maximum number of iterations in PATV 
% SARIMA model parameters
% p_arima % order of the AR term
% D_arima % order of the non-seasonal integration term
% q_arima % order of the MA term
% s_arima % seasonality

% OUTPUTS
% y_hat F-sample forecast of y
% y_hat_2p5: lower bound of the 95% confidence prediction interval
% y_hat_97p5: upper bound of the 95% confidence prediction interval

Ly=length(y);  % number of elements of y(n);
% L=168 samples for the time series at hand (from January 2012 to December 2025);

y_training=y(1:Ly);  % trims off the last F=24 samples of y(n) to form y_training(n)
y_training=y_training(:);  % makes y_training a column vector 
mu=mean(y_training);  % calculates the mean of y_training and stores it in \mu

y_training=y_training-mu; % removes the mean out of y_training
% y_training is zero-mean now
 
% PATV Decomposition (via patvmm.m) of y_training(n)

% Decomposition Model
% y_training(n) = t(n) + c(n) + s(n)
% t(n) is a d^th-order polynomial
% c(n) is by construction a piecewise constant function
% s(n) is whatever remains after removing t(n) and c(n) from y_training(n)

% PATV receives y_training(n) and outputs t(n) and c(n)
% after correcting the amplitude of c(n), i.e., c_a(n)=g*c(n) (see below)
% s(n) = y_training(n) - t(n) - c_a(n)  is the seasonal component

% Runs the PATV decomposition of y_training(n)
[c, t, bi, cost_c, cost_t] = patv_MM(y_training, d, lambda, N_ite);  % outputs c(n), t(n) and 
% the polynomial coefficients bi that generate t(n)
% c is a piece-wise constant component c(n) that captures the drop in hosp. admissions
% t is  d^th-order polynomial component t(n)
% bi are the coefficients of the polynomial that generate t(n)

% The minimum cost = cost_c + cost_t, after the PATV iterations are
% finished
% cost_t/Ly is an estimate of the variance of t(n)  
% cost_c/Ly is an estimate of the variance of c(n)


% Correction of the amplitude scale of c(n); (see paper)

w=y_training-t;  % noisy version of c(n)

g=(c'*w)/(c'*c);   % calculates the gain that corrects the amplitude of c(n)

c_a=g*c; % corrects the amplitude of c(n) and forms the sequence c_a(n)

s = y_training - t - c_a;  % seasonal component s(n)



% Extrapolation of the components: c_a(n), t(n), and s(n)

% zeroth-order extrapolation of c_a(n) 

% zeroth-order extrapolation of c_a(n) 
% considering uncertainty, i.e., variance of cost_c/Ly
c_hat=c_a(end)*ones(F,1);
c_hat_2p5=c_hat-1.96*sqrt(cost_c/Ly);  % lower-bound of the 95% prediction interval (PI)
c_hat_97p5=c_hat+1.96*sqrt(cost_c/Ly);  % lower-bound of the 95% prediction interval (PI)


% SARIMA model
% Builds a structure for the SARIMA model
model_struct = arima('Constant',0,'D',D_arima,'Seasonality',s_arima,'ARLags',1:p_arima);
[model_fit, var_COV] = estimate(model_struct,s);  % estimates the model parameters that best fits s(n) 
[s_hat,sMSE] = forecast(model_fit,F,'Y0',s); % model-based forecast of F samples to obtain s_hat
% s_hat is the mean forecast
% from sMSE one gets the prediction interval with 95% confidence

s_hat_2p5 = s_hat - 1.96*sqrt(sMSE);   % lower bound 
% for the prediction interval of 95% confidence
s_hat_97p5 = s_hat + 1.96*sqrt(sMSE); % upper bound 
% for the prediction interval of 95% confidence

% Extrapolation of t(n) considering the uncertainty cost_t/Nx:

% Generates a noisy t(n) with variance cost_t/Nx
t_noisy=t+sqrt(cost_t/Ly).*randn(size(t));  % polynomial tendency t(n) with uncertainty
% taken from cost_t/Nx, i.e., with variance cost_t/Nx

[bi_noisy,S] = polyfit((0:Ly-1)',t_noisy,d); % re_estimate the polynomial coefficients based on t(n) with uncertainty;
% S is the error estimation structure, which will be used for obtaining
% the 95% prediction interval for the extrapolated t(n)

[t_fit,delta] = polyconf(bi_noisy,(0:Ly-1+F)',S); % Obtain extrapolated t(n) with associated 95% prediction intervals
% stored in delta


t_hat= t_fit(end-(F-1):end);   % mean forecast \hat{t}(n)

t_hat_2p5= t_fit(end-(F-1):end)-delta(end-(F-1):end); % lower bound of th 95% prediction interval
% of the forecast \hat{t}(n)
t_hat_97p5= t_fit(end-(F-1):end)+delta(end-(F-1):end); % upper bound of th 95% prediction interval
% of the forecast \hat{t}(n)


% Builds the forecast y_hat(n) with the 95% confidence prediction interval
y_hat = s_hat + t_hat + c_hat + mu;  % mean forecast
y_hat_2p5 = s_hat_2p5 + t_hat_2p5 + c_hat_2p5 + mu;  % lower bound of the 95% confidence prediction interval
y_hat_97p5 = s_hat_97p5 + t_hat_97p5 + c_hat_97p5 +mu; % upper bound of the 95% confidence prediction interval

end

function [x, p, pc, cost_c, cost_t, cost, u, v] = patv_MM(y, d, lambda, Nit)
% [x, p, cost] = patv_MM(y, d, lambda, Nit)
% PATV: Simultaneous polynomial approximation and total variation denoising.
% Algorithm based on MM algorithm.
%
% INPUT
%   y - noisy data
%   d - order of polynomial
%   lambda - regularization parameter
%   Nit - number of iterations
%
% OUTPUT
%   x - TV component
%   p - polynomial component
%   cost - cost function history

% Ivan Selesnick, selesi@poly.edu
% Polytechnic Institute of New York University
% November 2012
% Reference: 'Simultaneous least square polynomial approximation and total variation denoising'
% ICASSP 2013

y = y(:);                   % convert to column vector
cost = zeros(1,Nit);        % cost function history
N = length(y);

G = orth(bsxfun(@power, (0:N-1)', 0:d));

e = ones(N-1,1);
STSinv = spdiags([-e 2*e -e], [-1 0 1], N-1, N-1);
STSinv(1,1) = 1;

S = @(x) [0; cumsum(x)];                % S : cumulative sum 
rev = @(x) x(end:-1:1,:);               % rev : reverse elements of vector
ST = @(x) rev(cumsum(rev(x(2:end,:)))); % ST : S'
H = @(x) x - G * (G'*x);                % H : I - G G'
B = ST(G);
C = G'*G;

b = ST(H(y));                           % b : S'*H(y);
u = ones(N-1, 1);                       % Initialization
x = S(u);
Dx = u;                                 % Dx = D*x = D*S*u = I*u = u

for k = 1:Nit        
    Lam = spdiags(abs(Dx)/lambda, 0, N-1, N-1);
    R = STSinv + Lam;                           % size(R) : (N-1) x (N-1)
    invA = @(x) Lam * (x - R \ (Lam * x));      % invA : (N-1) -> (N-1)
    Q = C - B' * invA(B);                       % Q : size(Q) = (d+1) x (d+1)
    u = invA(b + B * (Q \ (B' * invA(b))));    
    x = S(u);
    Dx = u;                             % Dx = D*x = D*S*u = I*u = u
    cost(k) = lambda * sum(abs(Dx)) + 0.5 * sum(abs(H(x - y)).^2);
end

cost_c=lambda * sum(abs(Dx));
cost_t=0.5 * sum(abs(H(x - y)).^2);

p = G * (G' * (y - x));
v = ST(H(y - x));

% Obtain polynomial coefficients pc
G = (bsxfun(@power, (0:N-1)', 0:d));
%pc=(G' * (y - x));
pc=(G'*G)\(G'* (y - x));

end