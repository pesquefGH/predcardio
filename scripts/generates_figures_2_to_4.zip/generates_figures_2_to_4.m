% Matlab script of the forecast method for the monthly number of
% hospital admissions due to cardiovascular diseases (per million inhabitants)
% in the public-health system (SUS), in Brazil 

% Generates figures 2 to 4 of the paper

% Paulo Esquef, Nov 2026

clear all
close all
clc


load adjusted_time_series.mat  % loads in vector y 
% the adjusted time series of
% the monthly number of hospital admissions due to cardiovascular 
% diseases (per million inhabitants) in the Brazilian 
% public-health system (SUS), 
% from January 2012 to December 2025

L=length(y);  % number of elements of y(n);
% L=168 samples for the time series at hand (from January 2012 to December 2025);

F=24; % Forecast horizon of 24 samples

Nx=L-F;  % Nx is the time index of the cutoff month of available data 
% used to train the predictor, i.e., up to December 2023.  

yo=y;  % stores in vector yo the original values of y 

% Temporal Selection 
y_training=y(1:Nx);  % trims off the last F=24 samples of y(n) to form y_training(n)
y_training=y_training(:);  % makes y_training a column vector 
mu=mean(y_training);  % calculates the mean of y_training and stores it in \mu

y_testing = y(Nx+1:L);  % forms y_testing(n) with the last F=24 samples 
% of y(n), i.e., from January 2024 to December 2025

y_training=y_training-mu; % removes the mean out of y_training
% y_training is zero-mean now
 
% PATV Decomposition (via patvmm.m) of y_training(n)

% Decomposition Model
% y_training(n) = t(n) + c(n) + s(n)
% t(n) is a d^th-order polynomial
% c(n) is by construction a piecewise constant function
% s(n) is whatever remains after removing t(n) and c(n) from y_training(n)

% PATV receives y_training(n) and outputs t(n) and c(n)
% after correcting the amplitude of c(n), i.e., c_a(n)=g*c(n) (see below)
% s(n) = y_training(n) - t(n) - c_a(n)  is the seasonal component

% PATV setup parameters chosen heuristically (see paper)

d=2; % order of the polynomial that generates t(n) 
N_ite = 100;  % maximum number of iterations (PATV)
lambda = 140;  % chosen value of lambda so that c_a(n) shows a 
% sag (related to the drop in hospital admissions) with the fewest number of levels
% (visual calibration; see paper)

% Runs the PATV decomposition of y_training(n)
[c, t, bi, cost_c, cost_t] = patv_MM(y_training, d, lambda, N_ite);  % outputs c(n), t(n) and 
% the polynomial coefficients bi that generate t(n)

% The minimum cost = cost_c + cost_t, after the PATV iterations are
% finished

% cost_t/Nx is an estimate of the variance of t(n)  

% cost_c/Nx is an estimate of the variance of c(n)



% c is a piece-wise constant component c(n) that captures the drop in hosp. admissions
% t is  d^th-order polynomial component t(n)
% bi are the coefficients of the polynomial that generate t(n)

% Correction of the amplitude scale of c(n); (see paper)

w=y_training-t;  % noisy version of c(n)

g=(c'*w)/(c'*c);   % calculates the gain that corrects the amplitude of c(n)

c_a=g*c; % corrects the amplitude of c(n) and forms the sequence c_a(n)

%trend=c_a+t;   % trend and drop components 

n=1:length(y_training); n=n(:); % time basis (for plotting purposes)

% compares the original series y_training(n) with the sum of the
% non-seasonal components, i.e.,  t(n)+c_a(n):

% Generates Figure 2 of the paper
figure, clf
plot(n, y_training+mu,'b', n, t+c_a+mu, 'black','linewidth',2)
set(gcf,'position',[695   273   744   506])
set(gca,'FontSize',15)
hx=xlabel('$n$ (time index)');
ylabel('HA by CVD per Million Inhab.')
hl=legend('$y_\textrm{training}(n)$','$t(n) + c_\textrm{a}(n)+\mu$','Location','Southwest');
set(hl,'interpreter','latex','FontSize',18);
set(hx,'interpreter','latex');
axis([1 145 213 343])

s = y_training - t - c_a;  % seasonal component s(n)

hx=xlabel('$n$ (time index)');
ylabel('HA by CVD per Million Inhab.')
set(hl,'interpreter','latex','FontSize',18);
set(hx,'interpreter','latex');


% Extrapolation of the components: c_a(n), t(n), and s(n)
% forecast horizon F=24 months

% zeroth-order extrapolation of c_a(n) 
% considering uncertainty, i.e., variance of cost_c/Nx
c_hat=c_a(end)*ones(F,1);
c_hat_2p5=c_hat-1.96*sqrt(cost_c/Nx);  % lower-bound of the 95% prediction interval (PI)
c_hat_97p5=c_hat+1.96*sqrt(cost_c/Nx);  % lower-bound of the 95% prediction interval (PI)

% Extrapolates c_a(n) with the associated prediction interval
% These 3 signals are calculated for plotting purposes only 
c_ext=[c_a;c_hat];  % extended c_a(n) by F samples (mean)
c_ext_2p5=[c_a;c_hat_2p5];  % extended c_a(n) by F samples (lower bound 95% PI)
c_ext_97p5=[c_a;c_hat_97p5];  % extended c_a(n) by F samples (upper bound 95% PI)

% generates Figure 3 (middle panel) of the paper
figure
plot(c_ext,'r','linewidth',2.8); hold on; 
plot(c_ext_2p5,'k')
plot(c_ext_97p5,'k')
plot(c_a,'b','linewidth',3); 
set(gca,'FontSize',15)
set(gcf,'position',[695   273   744   506])
hx=xlabel('$n$ (time index)');
ylabel('HA by CVD per Million Inhab.')
hl=legend(' $\hat{c}_\textrm{a}(n)$','lower-bound 95\% PI','upper-bound 95\% PI','$c_\textrm{a}(n)$','Location','Southwest');
set(hl,'interpreter','latex','FontSize',18);
set(hx,'interpreter','latex');
axis([1 169 -57 2])

% SARIMA model parameters for the forecast of s(n)
% Chosen heuristically (see paper)
p_arima=10; % order of the AR term
D_arima=0; % order of the non-seasonal integration term
q_arima=0; % order of the MA term
s_arima=12;  % seasonality

% Builds a structure for the SARIMA model
model_struct = arima('Constant',0,'D',D_arima,'Seasonality',s_arima,'ARLags',1:p_arima);
[model_fit, var_COV] = estimate(model_struct,s);  % estimates the model parameters that best fits s(n) 
[s_hat,sMSE] = forecast(model_fit,F,'Y0',s); % model-based forecast of F samples to obtain s_hat
% s_hat is the mean forecast
% from sMSE one gets the prediction interval with 95% confidence

s_hat_2p5 = s_hat - 1.96*sqrt(sMSE);   % lower bound for the prediction interval of 95% confidence
s_hat_97p5 = s_hat + 1.96*sqrt(sMSE); % upper bound for the prediction interval of 95% confidence

% Extended s(n) for plotting purposes
s_ext_mean=[s; s_hat];
s_ext_2p5=[s; s_hat_2p5];
s_ext_97p5=[s; s_hat_97p5];

% Generates Figure 3 (bottom panel)
figure
plot(s_ext_mean,'r','linewidth',2.8); hold on; 
set(gca,'FontSize',15)
set(gcf,'position',[695   273   744   506])
plot(s_ext_2p5,'k')
plot(s_ext_97p5,'k')
plot(s,'b','linewidth',3); 
hx=xlabel('$n$ (time index)');
ylabel('HA by CVD per Million Inhab.')
hl=legend('$\hat{s}(n)$','95\% PI ','95\% PI','$s(n)$','Location','Northwest');
set(hl,'interpreter','latex','FontSize',16);
set(hx,'interpreter','latex');

axis([1 169 -48 63])

% Extrapolation of t(n) considering the uncertainty cost_t/Nx:

% Generates a noisy t(n) with variance cost_t/Nx
t_noisy=t+sqrt(cost_t/Nx).*randn(size(t));  % polynomial tendency t(n) with uncertainty
% taken from cost_t/Nx, i.e., with variance cost_t/Nx

[bi_noisy,S] = polyfit((0:Nx-1)',t_noisy,d); % re_estimate the polynomial coefficients based on t(n) with uncertainty;
% S is the error estimation structure, which will be used for obtaining
% the 95% prediction interval for the extrapolated t(n)

[t_fit,delta] = polyconf(bi_noisy,(0:L-1)',S); % Obtain extrapolated t(n) with associated 95% prediction intervals
% stored in delta


t_hat= t_fit(end-(F-1):end);   % mean forecast \hat{t}(n)

t_hat_2p5= t_fit(end-(F-1):end)-delta(end-(F-1):end); % lower bound of th 95% prediction interval
% of the forecast \hat{t}(n)
t_hat_97p5= t_fit(end-(F-1):end)+delta(end-(F-1):end); % upper bound of th 95% prediction interval
% of the forecast \hat{t}(n)

% the 3 t_ext components below are calculated for plotting purposes only
t_ext=t_fit;  % extrapolated t(n), i.e., [t(n); \hat{t}(n)]  

t_ext_2p5=[t_fit(1:Nx); t_hat_2p5];  % lower bound of the 95% PI
t_ext_97p5=[t_fit(1:Nx); t_hat_97p5]; % upper bound of the 95% PI

% Generates Figure 3 (top panel) of the paper
figure
plot(t_ext,'r','linewidth',2.8); hold on; 
set(gca,'FontSize',15)
set(gcf,'position',[695   273   744   506])
plot(t_ext_2p5,'k')
plot(t_ext_97p5,'k')
plot(t_fit(1:Nx),'b','linewidth',3); 
hx=xlabel('$n$ (time index)');
ylabel('HA by CVD per Million Inhab.')
hl=legend('$\hat{t}(n)$','Lower Bound 95\% PI','Upper Bound 95\% PI','$t(n)$','Location','North');
set(hx,'interpreter','latex');
set(hl,'interpreter','latex','FontSize',18);

axis([1 L+1 -4 90])

% Builds the forecast y_hat(n) with the 95% confidence prediction interval
y_hat = s_hat + t_hat + c_hat + mu;  % mean forecast

y_hat_2p5 = s_hat_2p5 + t_hat_2p5 + c_hat_2p5 + mu;  % lower bound of the 95% confidence prediction interval
y_hat_97p5 = s_hat_97p5 + t_hat_97p5 + c_hat_97p5 +mu; % upper bound of the 95% confidence prediction interval


% Generates Figure 4


% Plots only the forecast period and compares with the actual
% hospital admission data in the same period

nf=Nx+1:L;   % time basis for the forecast period

figure


plot(nf,y_hat,'r','LineWidth',3); hold on
set(gca,'fontsize',15)
set(gcf,'position',[695   273   744   506])
plot(nf,y_testing,'b','LineWidth',3)
plot(nf,y_hat_2p5,'k','LineWidth',1)
plot(nf,y_hat_97p5,'k','LineWidth',1)
hx=xlabel('$n$ (time index)');
ylabel('HA by CVD per Million Inhab.')
hl=legend('$\hat{y}(n)$ [Forecast]','$y_\textrm{testing}(n)$ [Actual]',...
    'Lower Bound 95\% PI','Upper Bound 95\% PI','Location','Northwest');
set(hx,'interpreter','latex');
set(hl,'interpreter','latex','FontSize',15);

axis([Nx+1 L 220 470])


function [x, p, pc, cost_c, cost_t, cost, u, v] = patv_MM(y, d, lambda, Nit)
% [x, p, cost] = patv_MM(y, d, lambda, Nit)
% PATV: Simultaneous polynomial approximation and total variation denoising.
% Algorithm based on MM algorithm.
%
% INPUT
%   y - noisy data
%   d - order of polynomial
%   lambda - regularization parameter
%   Nit - number of iterations
%
% OUTPUT
%   x - TV component
%   p - polynomial component
%   cost - cost function history

% Ivan Selesnick, selesi@poly.edu
% Polytechnic Institute of New York University
% November 2012
% Reference: 'Simultaneous least square polynomial approximation and total variation denoising'
% ICASSP 2013

y = y(:);                   % convert to column vector
cost = zeros(1,Nit);        % cost function history
N = length(y);

G = orth(bsxfun(@power, (0:N-1)', 0:d));

e = ones(N-1,1);
STSinv = spdiags([-e 2*e -e], [-1 0 1], N-1, N-1);
STSinv(1,1) = 1;

S = @(x) [0; cumsum(x)];                % S : cumulative sum 
rev = @(x) x(end:-1:1,:);               % rev : reverse elements of vector
ST = @(x) rev(cumsum(rev(x(2:end,:)))); % ST : S'
H = @(x) x - G * (G'*x);                % H : I - G G'
B = ST(G);
C = G'*G;

b = ST(H(y));                           % b : S'*H(y);
u = ones(N-1, 1);                       % Initialization
x = S(u);
Dx = u;                                 % Dx = D*x = D*S*u = I*u = u

for k = 1:Nit        
    Lam = spdiags(abs(Dx)/lambda, 0, N-1, N-1);
    R = STSinv + Lam;                           % size(R) : (N-1) x (N-1)
    invA = @(x) Lam * (x - R \ (Lam * x));      % invA : (N-1) -> (N-1)
    Q = C - B' * invA(B);                       % Q : size(Q) = (d+1) x (d+1)
    u = invA(b + B * (Q \ (B' * invA(b))));    
    x = S(u);
    Dx = u;                             % Dx = D*x = D*S*u = I*u = u
    cost(k) = lambda * sum(abs(Dx)) + 0.5 * sum(abs(H(x - y)).^2);
end

cost_c=lambda * sum(abs(Dx));
cost_t=0.5 * sum(abs(H(x - y)).^2);

p = G * (G' * (y - x));
v = ST(H(y - x));

% Obtain polynomial coefficients pc
G = (bsxfun(@power, (0:N-1)', 0:d));
%pc=(G' * (y - x));
pc=(G'*G)\(G'* (y - x));

end