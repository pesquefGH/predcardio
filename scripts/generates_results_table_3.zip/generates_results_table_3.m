% Script to generate the results shown in table 3 of the paper

% Paulo Esquef, November 2026

clear all; close all; clc

load adjusted_time_series.mat  % loads adjusted time series in vector y

Ly=length(y); % length of y 

% Prediction Model Setup

F=24; % forecast horizon

y_testing=y(end-(F-1):end); % selects the F last samples of y for 
% prediction performance evaluation

y=y(1:Ly-F);  % actual time series used for training the predictors
% Two predictors will be evaluated
% Proposed predictor (PATV + SARIMA)
% SARIMA only predictor



% PATV parameters:
d=2;  % second-order order of the polynomial trend
lambda=140; % sag sensitivity parameter 
N_ite=100; % maximum number of iterations in PATV 
% SARIMA model parameters
%p_arima=10; % order of the AR term
D_arima=0; % order of the non-seasonal integration term
q_arima=0; % order of the MA term
s_arima=12; % seasonality


% Runs the proposed prediction model with reference implementation
% and p_arima in {10, 15, 20, 25}

p_arima_v=(10:5:25)';

% Runs a Monte Carlo (MC) Simulation (takes a long time to complete) or
% uses/loads pre-calculated data from a previous run MC simulation

Run_MC_simulation=0;  % binary selection MC simulation (1) or pre-calculated data (0) 

if ~Run_MC_simulation  %uses pre-calculated data
    load data_table_3 % loads MRE_p_SARIMA  MRE_p_proposed   
    
    T = table(p_arima_v,MRE_p_proposed,MRE_p_SARIMA)
    
    % rounded values up to one decimal point
    MRE_p_proposed=round(10*MRE_p_proposed)/10;
    MRE_p_SARIMA=round(10*MRE_p_SARIMA)/10;

    T_round=table(p_arima_v,MRE_p_proposed,MRE_p_SARIMA)
    

else  % runs another MC simulation  (takes a long time to complete)
    MRE_p_proposed=zeros(length(p_arima_v),1);
    MRE_p_SARIMA=zeros(length(p_arima_v),1);
    MC_runs=1000;  % number of MC runs for the proposed method
    y_hat_v=zeros(MC_runs,F);  % 1000 realizations of y_hat for a given p 
    y_hat_p=zeros(length(p_arima_v),F); % mean of y_hat_v for a given p
    y_hat_p_competing=zeros(length(p_arima_v),F);

    % Evaluates MRE(p) for the proposed method
    for k=1:length(p_arima_v)
        p_arima=p_arima_v(k);  % selects one p_arima of the set
        for n=1:MC_runs
            y_hat_v(n,:) = predcardio(y,F,d,lambda,N_ite,...
                p_arima,D_arima,q_arima,s_arima); % runs proposed predictor
        end
        y_hat_p(k,:)=mean(y_hat_v)'; %y_hat=y_hat(:);  
        relative_error=(y_testing-y_hat_p(k,:)')./y_testing;  % relative error between actual 
        % and forecast values
        MRE=100*mean(abs(relative_error)); % mean relative error in %
        MRE_p_proposed(k)=MRE;  % stores MRE value 
    end

    % Evaluates MRE(p) for the SARIMA only predictor
    D_arima=1;
    for k=1:length(p_arima_v)
        p_arima=p_arima_v(k);  % selects one p_arima of the set
        y_hat_p_competing(k,:)=sarima_pred(y,F,p_arima,D_arima,q_arima,s_arima);
        % runs SARIMA predictor
        relative_error=(y_testing-y_hat_p_competing(k,:)')./y_testing;  % relative error between actual 
        % and forecast values
        MRE=100*mean(abs(relative_error)); % mean relative error in %
        MRE_p_SARIMA(k)=MRE;  % stores MRE value 
    end

    T = table(p_arima_v,MRE_p_proposed,MRE_p_SARIMA)

    T_round=table(round(10*p_arima_v)/10,round(10*MRE_p_proposed)/10,round(10*MRE_p_SARIMA)/10)

    save data_table_3 y_hat_p y_hat_p_competing MRE_p_SARIMA  MRE_p_proposed   T   T_round y_hat_v

end


function [y_hat,y_hat_2p5,y_hat_97p5]=sarima_pred(y,F,p_arima,D_arima,q_arima,s_arima)

% INPUTS:
% y: input time series (adjusted per million inhabitants)
% F: forecast horizon in number of months
% (must be way smaller than the length of y)
% SARIMA model parameters
% p_arima % order of the AR term
% D_arima % order of the non-seasonal integration term
% q_arima % order of the MA term
% s_arima % seasonality

% OUTPUTS
% y_hat F-sample forecast of y
% y_hat_2p5: lower bound of the 95% confidence prediction interval
% y_hat_97p5: upper bound of the 95% confidence prediction interval

Ly=length(y);  % number of elements of y(n);
% L=168 samples for the time series at hand (from January 2012 to December 2025);

y_training=y(1:Ly);  % trims off the last F=24 samples of y(n) to form y_training(n)
y_training=y_training(:);  % makes y_training a column vector 
mu=mean(y_training);  % calculates the mean of y_training and stores it in \mu

y_training=y_training-mu; % removes the mean out of y_training
% y_training is zero-mean now


% SARIMA model
% Builds a structure for the SARIMA model
model_struct = arima('Constant',0,'D',D_arima,'Seasonality',s_arima,'ARLags',1:p_arima);
[model_fit, var_COV] = estimate(model_struct,y_training);  % estimates the model parameters that best fits y_training(n) 
[y_hat,sMSE] = forecast(model_fit,F,'Y0',y_training); % model-based forecast of F samples to obtain y_hat
% y_hat is the mean forecast
% from sMSE one gets the prediction interval with 95% confidence

y_hat_2p5 = y_hat - 1.96*sqrt(sMSE);   % lower bound 
% for the prediction interval of 95% confidence
y_hat_97p5 = y_hat + 1.96*sqrt(sMSE); % upper bound 
% for the prediction interval of 95% confidence

% Builds the forecast y_hat(n) with the 95% confidence prediction interval
y_hat = y_hat +mu;  % mean forecast
y_hat_2p5 = y_hat_2p5 + mu;  % lower bound of the 95% confidence prediction interval
y_hat_97p5 = y_hat_97p5 +mu; % upper bound of the 95% confidence prediction interval

end


function [y_hat,y_hat_2p5,y_hat_97p5]=predcardio(y,F,d,lambda,N_ite,...
    p_arima,D_arima,q_arima,s_arima)

% INPUTS:
% y: input time series (adjusted per million inhabitants)
% F: forecast horizon in number of months
% (must be way smaller than the length of y)
% PATV parameters:
% d: order of the polynomial trend
% lambda: sag sensitivity parameter (initial guess: 
% set lambda = largest drop in the time series)
% N_ite: maximum number of iterations in PATV 
% SARIMA model parameters
% p_arima % order of the AR term
% D_arima % order of the non-seasonal integration term
% q_arima % order of the MA term
% s_arima % seasonality

% OUTPUTS
% y_hat F-sample forecast of y
% y_hat_2p5: lower bound of the 95% confidence prediction interval
% y_hat_97p5: upper bound of the 95% confidence prediction interval

Ly=length(y);  % number of elements of y(n);
% L=168 samples for the time series at hand (from January 2012 to December 2025);

y_training=y(1:Ly);  % trims off the last F=24 samples of y(n) to form y_training(n)
y_training=y_training(:);  % makes y_training a column vector 
mu=mean(y_training);  % calculates the mean of y_training and stores it in \mu

y_training=y_training-mu; % removes the mean out of y_training
% y_training is zero-mean now
 
% PATV Decomposition (via patvmm.m) of y_training(n)

% Decomposition Model
% y_training(n) = t(n) + c(n) + s(n)
% t(n) is a d^th-order polynomial
% c(n) is by construction a piecewise constant function
% s(n) is whatever remains after removing t(n) and c(n) from y_training(n)

% PATV receives y_training(n) and outputs t(n) and c(n)
% after correcting the amplitude of c(n), i.e., c_a(n)=g*c(n) (see below)
% s(n) = y_training(n) - t(n) - c_a(n)  is the seasonal component

% Runs the PATV decomposition of y_training(n)
[c, t, bi, cost_c, cost_t] = patv_MM(y_training, d, lambda, N_ite);  % outputs c(n), t(n) and 
% the polynomial coefficients bi that generate t(n)
% c is a piece-wise constant component c(n) that captures the drop in hosp. admissions
% t is  d^th-order polynomial component t(n)
% bi are the coefficients of the polynomial that generate t(n)

% The minimum cost = cost_c + cost_t, after the PATV iterations are
% finished
% cost_t/Ly is an estimate of the variance of t(n)  
% cost_c/Ly is an estimate of the variance of c(n)


% Correction of the amplitude scale of c(n); (see paper)

w=y_training-t;  % noisy version of c(n)

g=(c'*w)/(c'*c);   % calculates the gain that corrects the amplitude of c(n)

c_a=g*c; % corrects the amplitude of c(n) and forms the sequence c_a(n)

s = y_training - t - c_a;  % seasonal component s(n)



% Extrapolation of the components: c_a(n), t(n), and s(n)

% zeroth-order extrapolation of c_a(n) 

% zeroth-order extrapolation of c_a(n) 
% considering uncertainty, i.e., variance of cost_c/Ly
c_hat=c_a(end)*ones(F,1);
c_hat_2p5=c_hat-1.96*sqrt(cost_c/Ly);  % lower-bound of the 95% prediction interval (PI)
c_hat_97p5=c_hat+1.96*sqrt(cost_c/Ly);  % lower-bound of the 95% prediction interval (PI)


% SARIMA model
% Builds a structure for the SARIMA model
model_struct = arima('Constant',0,'D',D_arima,'Seasonality',s_arima,'ARLags',1:p_arima);
[model_fit, var_COV] = estimate(model_struct,s);  % estimates the model parameters that best fits s(n) 
[s_hat,sMSE] = forecast(model_fit,F,'Y0',s); % model-based forecast of F samples to obtain s_hat
% s_hat is the mean forecast
% from sMSE one gets the prediction interval with 95% confidence

s_hat_2p5 = s_hat - 1.96*sqrt(sMSE);   % lower bound 
% for the prediction interval of 95% confidence
s_hat_97p5 = s_hat + 1.96*sqrt(sMSE); % upper bound 
% for the prediction interval of 95% confidence

% Extrapolation of t(n) considering the uncertainty cost_t/Nx:

% Generates a noisy t(n) with variance cost_t/Nx
t_noisy=t+sqrt(cost_t/Ly).*randn(size(t));  % polynomial tendency t(n) with uncertainty
% taken from cost_t/Nx, i.e., with variance cost_t/Nx

[bi_noisy,S] = polyfit((0:Ly-1)',t_noisy,d); % re_estimate the polynomial coefficients based on t(n) with uncertainty;
% S is the error estimation structure, which will be used for obtaining
% the 95% prediction interval for the extrapolated t(n)

[t_fit,delta] = polyconf(bi_noisy,(0:Ly-1+F)',S); % Obtain extrapolated t(n) with associated 95% prediction intervals
% stored in delta


t_hat= t_fit(end-(F-1):end);   % mean forecast \hat{t}(n)

t_hat_2p5= t_fit(end-(F-1):end)-delta(end-(F-1):end); % lower bound of th 95% prediction interval
% of the forecast \hat{t}(n)
t_hat_97p5= t_fit(end-(F-1):end)+delta(end-(F-1):end); % upper bound of th 95% prediction interval
% of the forecast \hat{t}(n)


% Builds the forecast y_hat(n) with the 95% confidence prediction interval
y_hat = s_hat + t_hat + c_hat + mu;  % mean forecast
y_hat_2p5 = s_hat_2p5 + t_hat_2p5 + c_hat_2p5 + mu;  % lower bound of the 95% confidence prediction interval
y_hat_97p5 = s_hat_97p5 + t_hat_97p5 + c_hat_97p5 +mu; % upper bound of the 95% confidence prediction interval

end

function [x, p, pc, cost_c, cost_t, cost, u, v] = patv_MM(y, d, lambda, Nit)
% [x, p, cost] = patv_MM(y, d, lambda, Nit)
% PATV: Simultaneous polynomial approximation and total variation denoising.
% Algorithm based on MM algorithm.
%
% INPUT
%   y - noisy data
%   d - order of polynomial
%   lambda - regularization parameter
%   Nit - number of iterations
%
% OUTPUT
%   x - TV component
%   p - polynomial component
%   cost - cost function history

% Ivan Selesnick, selesi@poly.edu
% Polytechnic Institute of New York University
% November 2012
% Reference: 'Simultaneous least square polynomial approximation and total variation denoising'
% ICASSP 2013

y = y(:);                   % convert to column vector
cost = zeros(1,Nit);        % cost function history
N = length(y);

G = orth(bsxfun(@power, (0:N-1)', 0:d));

e = ones(N-1,1);
STSinv = spdiags([-e 2*e -e], [-1 0 1], N-1, N-1);
STSinv(1,1) = 1;

S = @(x) [0; cumsum(x)];                % S : cumulative sum 
rev = @(x) x(end:-1:1,:);               % rev : reverse elements of vector
ST = @(x) rev(cumsum(rev(x(2:end,:)))); % ST : S'
H = @(x) x - G * (G'*x);                % H : I - G G'
B = ST(G);
C = G'*G;

b = ST(H(y));                           % b : S'*H(y);
u = ones(N-1, 1);                       % Initialization
x = S(u);
Dx = u;                                 % Dx = D*x = D*S*u = I*u = u

for k = 1:Nit        
    Lam = spdiags(abs(Dx)/lambda, 0, N-1, N-1);
    R = STSinv + Lam;                           % size(R) : (N-1) x (N-1)
    invA = @(x) Lam * (x - R \ (Lam * x));      % invA : (N-1) -> (N-1)
    Q = C - B' * invA(B);                       % Q : size(Q) = (d+1) x (d+1)
    u = invA(b + B * (Q \ (B' * invA(b))));    
    x = S(u);
    Dx = u;                             % Dx = D*x = D*S*u = I*u = u
    cost(k) = lambda * sum(abs(Dx)) + 0.5 * sum(abs(H(x - y)).^2);
end

cost_c=lambda * sum(abs(Dx));
cost_t=0.5 * sum(abs(H(x - y)).^2);

p = G * (G' * (y - x));
v = ST(H(y - x));

% Obtain polynomial coefficients pc
G = (bsxfun(@power, (0:N-1)', 0:d));
%pc=(G' * (y - x));
pc=(G'*G)\(G'* (y - x));

end