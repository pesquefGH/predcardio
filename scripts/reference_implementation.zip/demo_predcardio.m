% Script to demonstrate how to use the reference implementation predcardio
% 
% Paulo Esquef, July 2026

clear all; close all; clc

load adjusted_time_series.mat  % loads adjusted time series in vector y

Ly=length(y); % length of y 

% Prediction Model Setup

F=24; % forecast horizon

y_testing=y(end-(F-1):end); % selects the F last samples of y for 
% prediction performance evaluation

y=y(1:Ly-F);  % actual time series used for training the predictor



% PATV parameters:
d=2;  % second-order order of the polynomial trend
lambda=140; % sag sensitivity parameter 
N_ite=100; % maximum number of iterations in PATV 
% SARIMA model parameters
p_arima=10; % order of the AR term
D_arima=0; % order of the non-seasonal integration term
q_arima=0; % order of the MA term
s_arima=12; % seasonality




% Runs the prediction model with reference implementation

[y_hat,y_hat_2p5,y_hat_97p5] = predcardio(y,F,d,lambda,N_ite,...
    p_arima,D_arima,q_arima,s_arima);


% Plots the original series and the attained 
% forecast with the 95% confidence prediction interval
figure
plot(y,'b','linewidth',3); hold on; 
set(gcf,'position',[695   273   744   506])
set(gca,'FontSize',15)
y2 = y_hat'; % mean forecast 
rgf = (Ly-F)+(1:F);
curve1 = y_hat_97p5';
curve2 = y_hat_2p5';
x2 = [rgf, fliplr(rgf)];
inBetween = [curve1, fliplr(curve2)];

fill(x2, inBetween, [0.851 0.91 0.8339]);
hold on;
plot(rgf, y2, 'r', 'LineWidth', 3);
set(gcf,'position',[695   273   744   506])
ht=title('24 Months Forecast of $y(n)$');
hx=xlabel('$n$ (time index)');
ylabel('# Monthly Hosp. Admissions per Million Inhab.')
hl=legend('$y(n)$','CI 95\%','$\hat{y}(n)$','Location','Southwest');
set(hx,'interpreter','latex');
set(ht,'interpreter','latex');
set(hl,'interpreter','latex','FontSize',18);
axis([1 169 212 396])


nf=length(y)+(1:F);   % time basis for the forecast period

figure

plot(nf,y_hat,'r','LineWidth',3); hold on
set(gca,'fontsize',15)
set(gcf,'position',[695   273   744   506])
plot(nf,y_testing,'b','LineWidth',3)
plot(nf,y_hat_2p5,'k','LineWidth',1)
plot(nf,y_hat_97p5,'k','LineWidth',1)
hx=xlabel('$n$ (time index)');
ylabel('# Monthly Hosp. Admissions per Million Inhab.')
title('Forecast Results')
hl=legend('$\hat{y}(n)$ [Forecast]','$y_\textrm{testing}(n)$ [Actual]',...
    'Lower Bound 95\% PI','Upper Bound 95\% PI','Location','Northwest');
set(hx,'interpreter','latex');
set(hl,'interpreter','latex','FontSize',16);
axis([145 168 200 500])

% Performance evaluation

error=(y_testing-y_hat);

Ne=length(error);

RMSE=sqrt((error'*error)/Ne)

relative_error=error./y_testing;

MRE=100*mean(abs(relative_error))

